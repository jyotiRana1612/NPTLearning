﻿using System;
using System.Text;
using Newtonsoft.Json;
using Microsoft.ServiceBus.Messaging;

namespace EventTrigger
{
    class Program
    {
        static double _probability = 0.01;
        static int _transactions = 0;
        static int _cardNumber = -1;
        static string _connectionString = "Endpoint=sb://neupocjreventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=muPhlQMBASo3ylSRje3eum477iRb/OQTc7jdMQ+noiQ=";

        static void Main(string[] args)
        {
            var rand = new Random();
            var client = EventHubClient.CreateFromConnectionString(_connectionString, "neupocjreventhubforadb");

            while (true)
            {
                int card = 123456789 + rand.Next(0, 888888888);

                // Occasionally generate a fraudulent transaction by reusing a card number  
                if (rand.NextDouble() < _probability && _cardNumber != -1)
                {
                    card = _cardNumber;
                    _cardNumber = -1;
                }

                // Formulate a transaction  
                var transaction = new
                {
                    transactionId = _transactions++,
                    transactionTime = DateTime.UtcNow.ToString(),
                    deviceId = 12345 + rand.Next(0, 88888),
                    cardNumber = card,
                    amount = rand.Next(1, 20) * 20
                };

                // Occasionally record a card number for later use in generating fraud  
                if (rand.NextDouble() < _probability)
                {
                    _cardNumber = transaction.cardNumber;
                }

                // Send an event to the event hub  
                var message = JsonConvert.SerializeObject(transaction);
                client.Send(new EventData(Encoding.UTF8.GetBytes(message)));
                Console.WriteLine("[{0}] Event transmitted", message);
            }
        }
    }
}